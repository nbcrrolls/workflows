matlabpool local 8
collect
matlabpool close
quit
